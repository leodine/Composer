<?php

require_once __DIR__ . '/../vendor/autoload.php';

use App\Wcs\Hello;

$hello = new Hello();
$hello->talk();

?>
