<?php

// Hello.php

namespace App\Wcs;

class Hello
{
    
    public function talk(): void
    {
        echo "Hello World !";
    }

}

?>
